// ---------- Mobile nav ----------
function toggleNav(){
  document.getElementById('navLinks').classList.toggle('open');
}

// ---------- Highlight active nav link ----------
(function(){
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a=>{
    if(a.getAttribute('href') === path) a.classList.add('active');
  });
})();

// ---------- Speech helper (used across pages) ----------
function speak(text, rate){
  if(!('speechSynthesis' in window)){
    alert("Sorry, this browser can't speak out loud. Try Chrome or Edge.");
    return;
  }
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = rate || 0.85;
  u.pitch = 1.1;
  const voices = window.speechSynthesis.getVoices();
  const enVoice = voices.find(v => v.lang && v.lang.startsWith('en'));
  if(enVoice) u.voice = enVoice;
  window.speechSynthesis.speak(u);
}
// Some browsers load voices async — warm them up.
if('speechSynthesis' in window){
  window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
}
